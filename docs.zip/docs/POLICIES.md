# ZollPilot Development Policies

**Enforcement:** These policies are enforced through CI gates (Phase 0.8+) and code review.

## 1. Test-Driven Development (TDD)

### Policy
All code must be written test-first.

### Requirements
- Write failing test before implementation
- No implementation without corresponding tests
- **ENFORCED:** Minimum 80% code coverage (lines, functions, branches, statements)
- Critical paths require 100% coverage

### Coverage Enforcement (Phase 0.4+)

**Automated threshold checks:**
- Lines: ≥80%
- Functions: ≥80%
- Branches: ≥80%
- Statements: ≥80%

**Command:** `pnpm test:coverage`

**Enforcement:** The test:coverage command will FAIL if any threshold is not met. This prevents merging code with insufficient coverage.

**Configuration:** See `apps/web/vitest.config.ts` for threshold settings.

### Process
```
1. Write test (red)
2. Write minimal code to pass (green)
3. Refactor (refactor)
4. Verify coverage: pnpm test:coverage
5. Commit
```

### Exceptions
None. TDD is mandatory. Coverage thresholds are enforced.

## 2. Nothing Undocumented

### Policy
Every feature, API, and configuration must be documented before or during implementation.

### Requirements
- User-facing features → `docs/USER_MANUAL.md`
- Admin features → `docs/ADMIN_MANUAL.md`
- Architecture decisions → `docs/ARCHITECTURE.md` or ADRs
- Setup/deployment changes → `docs/SETUP.md`
- Code-level documentation via JSDoc for public APIs

### Doc-Drift Checks
- Automated checks in CI (Phase 0.10)
- PRs blocked if documentation is missing or outdated
- Enforce via `pnpm docs:check`

### Exceptions
Internal implementation details and private functions may be documented inline only.

## 3. Commit & PR Standards

### Commit Messages
Follow Conventional Commits:

```
<type>: <description>

[optional body]

[optional footer]
```

Types: `feat`, `fix`, `docs`, `test`, `chore`, `refactor`, `style`, `perf`

Examples:
```
feat: add user authentication
fix: resolve null pointer in pricing calculator
docs: update setup guide for Docker
test: add E2E tests for admin dashboard
```

### Pull Request Requirements
- Descriptive title and description
- Link to issue/ticket (if applicable)
- Tests included and passing
- Documentation updated
- CI checks passing
- Min. 1 code review approval

## 4. Branch Conventions

### Branch Naming
```
<type>/<short-description>

Examples:
- feature/user-authentication
- fix/pricing-calculation-bug
- docs/api-documentation
- chore/dependency-updates
```

### Protected Branches
- `main`: Production-ready code only
- Requires PR and passing CI
- Direct commits forbidden

## 5. Code Quality Standards

### TypeScript
- Strict mode enabled
- No `any` without justification comment
- Prefer interfaces for public APIs
- Use type inference where reasonable

### Linting & Formatting
- ESLint enforced
- Prettier enforced
- Pre-commit hooks (Phase 0.7+)
- CI blocks non-compliant code (Phase 0.8+)

### Code Review
- All PRs require review
- Security-sensitive changes require 2+ reviews
- Use inline comments for questions
- Resolve all comments before merge

## 6. Logging & Audit Policy

### Admin Action Audit
**MANDATORY:** Every admin action must generate an immutable audit event.

### Audit Event Requirements (Phase 0.12)

**Required Fields:**
- `tenantId` (UUID) - Multi-tenant isolation
- `action` (string) - Action type from AUDIT_ACTIONS constant
- `requestId` (string) - Request correlation ID (from x-request-id header)
- `createdAt` (timestamp) - Auto-generated, immutable

**Optional Fields:**
- `actorUserId` (UUID) - User who performed action (null for system actions)
- `entityType` (string) - Type of entity affected (e.g., "User", "Shipment")
- `entityId` (string) - ID of entity affected
- `ipAddress` (string) - Client IP address
- `userAgent` (string) - Client user agent
- `metadata` (JSON, max 10KB) - Additional context

### Standard Audit Actions

Use constants from `apps/web/src/server/audit.ts`:
- `SYSTEM_SEED` - Database initialization
- `USER_CREATED`, `USER_UPDATED`, `USER_DELETED` - User management
- `PRICING_UPDATED`, `PRICING_EXPORTED` - Pricing operations
- Add new actions as needed to the `AUDIT_ACTIONS` constant

### Audit Log Storage
- **Immutable** - NEVER update or delete audit events (append-only)
- **Database-backed** - Stored in `audit_events` table via Prisma
- **Encrypted at rest** - Database-level encryption
- **Retention:** Minimum 2 years recommended for compliance
- **Regular backups** - Included in database backup strategy

### Implementation (Phase 0.12)

**Helper Function:**
```typescript
import { logAuditEvent, AUDIT_ACTIONS } from '@/server/audit';

await logAuditEvent(prisma, {
  tenantId: 'tenant-123',
  actorUserId: 'user-456',
  action: AUDIT_ACTIONS.USER_CREATED,
  entityType: 'User',
  entityId: 'user-789',
  requestId: request.headers.get('x-request-id') || 'unknown',
  ipAddress: request.headers.get('x-forwarded-for') || null,
  userAgent: request.headers.get('user-agent') || null,
  metadata: { email: 'newuser@example.com', role: 'USER' },
});
```

**Validation:**
- Helper enforces required fields (throws if missing)
- Metadata size limited to 10KB (enforced)
- Integration tests ensure compliance

## 7. Security Policies

### Secrets Management
- Never commit secrets to repository
- Use environment variables for sensitive config
- Rotate credentials regularly
- Use secret scanning tools

### Dependency Management (Phase 0.9.2)

**Automated Scanning:**
- Dependabot scans dependencies weekly (Mondays, 06:00 Europe/Berlin)
- Automatically creates PRs for:
  - Security vulnerabilities (via Dependabot security updates)
  - Version updates for npm packages and GitHub Actions
- Updates grouped to reduce noise:
  - `dev-dependencies` group (tooling updates)
  - `runtime-dependencies` group (framework/library updates)

**Review and Merge Timelines:**

| Update Type | Review SLA | Merge SLA | Reviewer |
|-------------|-----------|-----------|----------|
| **Critical security** (CVSS ≥9.0) | 4 hours | 8 hours | Any maintainer + post-merge notification |
| **High security** (CVSS 7.0-8.9) | 1 business day | 2 business days | Any maintainer |
| **Medium/Low security** (CVSS <7.0) | 3 business days | 5 business days | Any maintainer |
| **Major version updates** | 5 business days | Sprint planning | Tech lead review required |
| **Minor/patch updates** (grouped) | 3 business days | 5 business days | Any maintainer |

**Review Requirements:**
- All Dependabot PRs must pass CI (quality, integration, e2e)
- Security updates: Check changelog for breaking changes, test locally if high-risk
- Major updates: Requires migration plan and tech lead approval
- Grouped updates: Review all changes in the group, not just first package

**Emergency Security Patch Workflow:**

1. **Identification (within 1 hour of alert)**
   - Dependabot creates security update PR automatically
   - GitHub Security tab shows alert severity and affected versions

2. **Assessment (within 2 hours)**
   - Review CVE details and exploitability
   - Check if vulnerability affects our usage (dead code paths can defer)
   - Determine if hotfix needed or can wait for next sprint

3. **Hotfix Process (for critical/high severity)**
   ```bash
   # Create hotfix branch from main
   git checkout main
   git pull
   git checkout -b hotfix/CVE-YYYY-NNNNN

   # Cherry-pick Dependabot commit or update manually
   pnpm update <affected-package>@<safe-version>

   # Run full test suite
   pnpm test && pnpm test:integration && pnpm test:e2e

   # Create PR with security label
   gh pr create --title "fix(security): patch CVE-YYYY-NNNNN" \
                --label "security" --label "hotfix"

   # Fast-track review and merge
   # Deploy immediately after merge
   ```

4. **Post-Patch (within 24 hours)**
   - Notify team in security channel
   - Document incident in security log
   - Update dependencies across all branches if needed

**Dependency Audit:**
- `pnpm audit` runs in CI on every PR (planned for Phase 0.9.3)
- Weekly manual audit review (Fridays)
- Quarterly full dependency review and cleanup

**Restrictions:**
- No direct commits of `package.json` or `pnpm-lock.yaml` without PR
- No `--force` flag for dependency installs without documented reason
- No pinning dependencies to vulnerable versions without security exception

### CodeQL Findings (Phase 0.9.3)

**Automated Static Analysis:**
- CodeQL scans all JavaScript/TypeScript code on PRs and pushes to `main`
- Weekly scheduled scans (Mondays, 06:00 UTC)
- Uses `security-and-quality` query suite for comprehensive coverage
- Results uploaded to GitHub Security dashboard

**Severity Handling:**

| Severity | Response SLA | Remediation SLA | Action Required |
|----------|-------------|-----------------|-----------------|
| **Critical** | 4 hours | 1 business day | Immediate fix, hotfix branch if in production |
| **High** | 1 business day | 3 business days | Priority fix, cannot merge PR with new high findings |
| **Medium** | 3 business days | 1 sprint | Fix in current/next sprint, can merge with justification |
| **Low** | 1 sprint | 2 sprints | Fix when convenient, tech debt backlog |

**Remediation Workflow:**

1. **Alert Notification (automatic)**
   - CodeQL findings appear in PR checks
   - Security tab shows all alerts with severity
   - GitHub can notify security team (configure in Settings → Code security)

2. **Triage (within Response SLA)**
   - Review alert description and data flow
   - Determine if it's a true positive or false positive
   - Check if code path is reachable in production
   - Assess exploitability and business impact

3. **Resolution (within Remediation SLA)**

   **For True Positives:**
   - Fix the vulnerability following CodeQL remediation guidance
   - Add test case to prevent regression
   - Document fix in commit message with CVE/CWE reference
   - Mark alert as "Fixed" (happens automatically on merge)

   **For False Positives:**
   - Document why it's a false positive (code never executes, input validated elsewhere, etc.)
   - Add code comment explaining safety
   - Dismiss alert in GitHub Security tab with reason
   - Consider adding suppression comment if appropriate

4. **Verification**
   - Re-run CodeQL scan after fix
   - Verify alert marked as "Fixed" or "Dismissed"
   - Update security documentation if pattern is common

**PR Merge Rules:**
- **Critical/High:** Must be fixed before merging (no exceptions)
- **Medium:** Can merge with tech lead approval + issue filed
- **Low:** Can merge freely, track in backlog

**False Positive Rate Management:**
- Track false positive rate monthly
- If FP rate >30%, consider adjusting query suite or adding suppressions
- Document common false positives in team wiki

**Dismissal Reasons (valid):**
- False positive (explain why)
- Won't fix (technical debt accepted, not exploitable)
- Used in tests (test code, not production)

**Dismissal Reasons (invalid):**
- "Too hard to fix" (not acceptable for Critical/High)
- "No time" (prioritize security over features)
- "Unlikely to be exploited" (without evidence)

### Input Validation
- Validate all user input
- Sanitize all output
- Use parameterized queries
- Follow OWASP top 10 guidelines

### Authentication & Authorization
- Enforce strong passwords
- Implement rate limiting
- Use secure session management
- RBAC for admin functions

## 8. CI/CD Gates

### Quality Gates (ENFORCED in Phase 0.4+)

**Locally Enforced (before commit):**
- ✅ TypeScript type checking (`pnpm typecheck`)
- ✅ Linting (`pnpm lint`)
- ✅ Code formatting (`pnpm format`)
- ✅ Unit tests with ≥80% coverage (`pnpm test:coverage`)

**Run all gates:**
```bash
pnpm lint && pnpm typecheck && pnpm test:coverage && pnpm format
```

### Pre-Merge Gates (Phase 0.8+ CI Automation)

**Phase 0.8:** CI pipeline runs automatically on all pull requests.
**Phase 0.9.1:** CI becomes a merge gate via GitHub branch protection (requires manual configuration).

#### CI Pipeline Status (Phase 0.8+)

The following checks **run automatically** on every pull request:

- ✅ TypeScript type checking (strict mode) - **RUNS IN CI**
- ✅ Linting (ESLint) - **RUNS IN CI**
- ✅ Code formatting (Prettier) - **RUNS IN CI**
- ✅ Unit tests (≥80% coverage) - **RUNS IN CI**
- ✅ Integration tests (Postgres + Prisma) - **RUNS IN CI**
- ✅ E2E tests (Playwright smoke tests) - **RUNS IN CI**
- ✅ Documentation drift check (Phase 0.10) - **RUNS IN CI**
- ✅ Security audit - high/critical vulnerabilities (Phase 0.11) - **RUNS IN CI**

#### Enforcement Status (Phase 0.9.1)

**IMPORTANT DISTINCTION:**
- **"RUNS IN CI"** means the check executes automatically on PRs
- **"ENFORCED AS MERGE GATE"** means GitHub blocks merging if the check fails

**Current Enforcement Status:**

With **branch protection configured** (manual GitHub setup required):
- ✅ CI checks become **MERGE GATES** - PRs cannot merge if CI fails
- ✅ PR approvals required - At least 1 reviewer must approve
- ✅ Up-to-date branches required - Branch must be current with base
- ✅ Direct commits blocked - All changes must go through PRs

Without branch protection (default):
- ⚠️ CI runs but **does not block merging**
- ⚠️ Failed CI checks show warnings but allow merge
- ⚠️ No approval required - Authors can merge their own PRs
- ⚠️ Direct commits allowed - Can push directly to `main`

**To enable enforcement:** Follow the Branch Protection Setup guide in `docs/CONTRIBUTING.md`

### Deployment Gates
- All CI gates passing
- Code review approved
- No known critical vulnerabilities
- Rollback plan documented

## 9. Documentation Standards

### Structure
- Use markdown for all docs
- Include table of contents for long docs
- Use code blocks with syntax highlighting
- Include examples where applicable

### Updates
- Update docs in same PR as code changes
- Version docs with releases
- Archive old versions
- Keep CHANGELOG.md current

### Review
- Docs reviewed as part of PR
- Technical accuracy verified
- Clarity and completeness checked

### Drift Prevention (Phase 0.10)

**Policy:** Documentation must stay in sync with code at all times. Documentation drift is a merge-blocking failure.

**Automated Checks:**
- `pnpm docs:check` runs in CI on every PR
- Validates internal markdown links (file existence, anchors)
- Verifies documented routes/endpoints exist in codebase
- Fails CI if drift detected

**Developer Responsibilities:**
- Run `pnpm docs:check` locally before committing documentation changes
- Update documentation in the **same PR** as code changes
- Never merge code that breaks documented routes without updating docs
- Use allowlist (`scripts/docs-check.config.json`) only for planned features with justification

**Allowlist Rules:**
- Allowlist is for **planned features only** (e.g., documented in Phase 1 but not yet implemented)
- All allowlist entries must include:
  - Reason/justification comment
  - Phase/sprint reference for implementation
  - Regular quarterly review to remove obsolete entries
- **Anti-pattern:** Adding items to allowlist to avoid fixing drift

**Remediation SLA:**
- Documentation drift found in PR review: **Must fix before merge** (no exceptions)
- Documentation drift found post-merge: **Fix within 1 business day**
- Broken external links: **Fix within 1 week** (non-blocking)

## 10. Monitoring & Observability (Phase 0.12)

### Request ID Propagation

**MANDATORY:** All HTTP requests must include a correlation ID for distributed tracing.

**Header:** `x-request-id`
**Format:** UUID v4 (e.g., `550e8400-e29b-41d4-a716-446655440000`)

**Rules:**
- Middleware reads incoming `x-request-id` or generates new UUID v4
- Response MUST include `x-request-id` header (same value)
- All structured logs SHOULD include `requestId` field
- All audit events MUST include `requestId` field (required)

**Implementation:** `apps/web/middleware.ts` (applies to all routes except static files)

### Application Logging

**MANDATORY:** Use structured logging helper for all server-side logs.

**Format:** JSON Lines (one JSON object per line)

**Required Fields:**
- `ts` (string) - ISO 8601 timestamp in UTC
- `level` (string) - Log level: info, warn, error, debug
- `msg` (string) - Human-readable message (snake_case preferred)
- `scope` (string) - Scope identifier (dot-separated, e.g., "api.health")

**Optional Fields:**
- `requestId` (string) - Request correlation ID (include when available)
- `meta` (object) - Additional structured metadata
- `error` (object) - Error details (name, message, stack)

**Security Guardrails:**
- ❌ NEVER log: passwords, tokens, API keys, credit cards, SSNs, complete session cookies
- ✅ DO log: request IDs, user IDs (opaque), email addresses (audit only), timestamps, durations

**Implementation:**
```typescript
import { logger } from '@/server/logger';

logger.info({
  msg: 'user_created',
  scope: 'api.users',
  requestId: request.headers.get('x-request-id') || undefined,
  meta: { userId: 'user-123' },
});
```

**Enforcement:**
- Use `logger.info/warn/error/debug` instead of `console.log`
- Code review checks for PII leakage in logs
- No string interpolation in `msg` field (use `meta` for dynamic values)

### Metrics

**Current Status:** Not yet implemented (planned for Phase 1+)

**Planned:**
- Track key performance indicators
- Monitor error rates
- Alert on anomalies
- Dashboard for real-time visibility

### Tracing

**Current Status:** Request ID propagation only (Phase 0.12)

**Planned (Phase 1+):**
- OpenTelemetry integration for distributed tracing
- Performance profiling and span tracking
- Database query monitoring

---

## Policy Enforcement

These policies are enforced through:
1. **Pre-commit hooks** (Phase 0.7+) - Local enforcement before commits
2. **Automated CI checks** (Phase 0.8+) - Run on all pull requests
3. **Branch protection** (Phase 0.9.1) - Blocks merging if CI fails (requires GitHub configuration)
4. **Code review** (all PRs) - Human review and approval required
5. **Regular audits** (quarterly) - Periodic compliance reviews

**Enforcement Layers:**
- **Local (pre-commit/pre-push):** Fast feedback, can be bypassed with `--no-verify`
- **CI Pipeline (automated):** Runs on every PR, provides visibility but doesn't block by default
- **Branch Protection (merge gate):** **Only enforcement layer that prevents merging** - must be configured in GitHub

Violations may result in PR rejection or required rework.

## Policy Updates

This document is versioned and updated as needed. All changes require:
- Team review and consensus
- Documentation of rationale
- Communication to all contributors
