# Contributing Guidelines

## Core Principles

### 1. Test-Driven Development (TDD)

**MANDATORY:** Write tests BEFORE implementation.

```
Process:
1. Write failing test
2. Write minimal code to pass test
3. Refactor
4. Repeat
```

No implementation will be accepted without corresponding tests.

### 2. Nothing Undocumented

**MANDATORY:** Every feature must be documented.

- Public features → `USER_MANUAL.md`
- Admin features → `ADMIN_MANUAL.md`
- Technical decisions → `ARCHITECTURE.md`
- Setup changes → `SETUP.md`

**Doc-drift checks are enforced in CI** (implemented in Phase 0.10).

### 3. Code Quality

- TypeScript strict mode enabled
- No `any` types without explicit justification
- ESLint and Prettier enforced
- 100% type coverage for public APIs

## Development Workflow

### Branch Strategy

```
main              - Production-ready code
├── feature/*     - New features
├── fix/*         - Bug fixes
├── docs/*        - Documentation updates
└── chore/*       - Maintenance tasks
```

### Commit Conventions

Follow conventional commits:

```
feat: add user authentication
fix: resolve login redirect issue
docs: update API documentation
test: add unit tests for user service
chore: update dependencies
```

**Enforced Locally:** Commit messages are validated automatically via git hooks (Phase 0.7+).

### Local Hooks (Phase 0.7+)

Git hooks are automatically installed on `pnpm install` and enforce quality standards before commits and pushes.

#### What Runs When

**On Commit (pre-commit):**
- `lint-staged` runs on staged files only
  - TypeScript files: ESLint --fix + Prettier --write
  - Markdown, JSON, YAML: Prettier --write
- **Fast** - only checks files you're committing

**On Commit Message (commit-msg):**
- `commitlint` validates conventional commit format
- Rejects invalid commit messages
- Ensures: `type(scope): subject` format

**On Push (pre-push):**
- Unit tests run (`pnpm test:unit`)
- **Fast** - integration/E2E tests NOT included
- Blocks push if tests fail

#### Running Manually

You can run the same checks manually:

```bash
# Lint staged files (same as pre-commit hook)
pnpm lint-staged

# Validate commit message (replace with your message)
echo "feat: add new feature" | npx commitlint

# Run unit tests (same as pre-push hook)
pnpm test:unit

# Run all quality gates
pnpm lint && pnpm typecheck && pnpm test:unit
```

#### Bypassing Hooks (Emergency Only)

**WARNING:** Only bypass hooks in emergencies. Your PR will fail in CI if quality gates don't pass.

```bash
# Skip pre-commit hook
git commit --no-verify -m "emergency fix"

# Skip pre-push hook
git push --no-verify
```

**Best Practice:** Fix the issues instead of bypassing. Use `--no-verify` only for:
- Emergency hotfixes that will be immediately fixed in a follow-up commit
- Reverting broken commits
- Work-in-progress commits in personal feature branches (discouraged)

#### Troubleshooting Hooks

**Hooks not running:**
```bash
# Reinstall hooks
pnpm install
# Or manually
npx husky install
```

**Commit message rejected:**
```bash
# Bad - will be rejected
git commit -m "fixed bug"
git commit -m "WIP"

# Good - will pass
git commit -m "fix: resolve authentication bug"
git commit -m "chore: update dependencies"
```

**lint-staged issues:**
```bash
# Run manually to see errors
pnpm lint-staged

# Fix formatting issues
pnpm format:write

# Fix linting issues
pnpm lint --fix
```

### Pull Request Process

1. Create feature branch from `main`
2. Write tests first (TDD)
3. Implement feature
4. Update documentation
5. Run all checks locally:
   ```bash
   pnpm lint
   pnpm typecheck
   pnpm test
   pnpm docs:check
   ```
6. Create PR with descriptive title and description
7. Address review feedback
8. Merge after approval and passing CI

### Database Workflow (Phase 0.3+)

When working with database changes:

#### 1. Start the Database

```bash
pnpm db:up
```

#### 2. Make Schema Changes

Edit `apps/web/prisma/schema.prisma`:

```prisma
model NewModel {
  id        String   @id @default(uuid())
  // ... fields
}
```

#### 3. Create and Apply Migration

```bash
pnpm prisma:migrate
```

This will:
- Prompt for a migration name (use descriptive names: `add-new-model`)
- Generate a migration file in `prisma/migrations/`
- Apply the migration to your local database
- Regenerate Prisma client

#### 4. Update Seed Script (if needed)

If your changes require seed data updates, modify `prisma/seed.ts`.

#### 5. Test Database Changes

```bash
# Verify database connectivity
pnpm db:smoke

# Run your tests
pnpm test
```

#### 6. Include Migration in PR

Commit the generated migration files:
```bash
git add apps/web/prisma/migrations/
git add apps/web/prisma/schema.prisma
git commit -m "feat: add new model to database schema"
```

#### Common Database Commands

```bash
# Start database
pnpm db:up

# Stop database (keeps data)
pnpm db:down

# Reset database (DESTRUCTIVE - deletes all data)
pnpm db:reset

# Generate Prisma client
pnpm prisma:generate

# Create and apply migration
pnpm prisma:migrate

# Seed database
pnpm prisma:seed

# Open Prisma Studio GUI
pnpm prisma:studio

# Run smoke test
pnpm db:smoke
```

#### Database Testing Best Practices

- Always test migrations locally before committing
- Never modify existing migration files (create new ones)
- Update seed data to match schema changes
- Run `pnpm db:smoke` to verify changes

### PR Requirements (Gates)

All PRs must pass:
- ✅ All tests (unit, integration, E2E)
- ✅ Type checking
- ✅ Linting
- ✅ Code formatting
- ✅ Coverage thresholds (≥80%)
- ✅ Documentation drift check
- ✅ Code review (min. 1 approval)

## CI Pipeline (Phase 0.8+)

The CI pipeline runs automatically on pull requests and pushes to main/feature branches. It enforces all quality gates and must pass before merging.

### CI Jobs

The pipeline consists of three parallel jobs:

#### 1. Quality Gates Job

**What it does:**
- Checks code formatting with Prettier
- Runs ESLint for code quality
- Runs TypeScript type checking
- Runs unit tests with coverage enforcement (≥80%)

**Local equivalent:**
```bash
pnpm format        # Check formatting
pnpm lint          # Run ESLint
pnpm typecheck     # Type check
pnpm test:coverage # Unit tests with coverage
```

**Common failures:**
- **Format check fails:** Run `pnpm format:write` to auto-fix
- **Lint fails:** Run `pnpm lint --fix` or fix manually
- **Type errors:** Fix TypeScript errors in reported files
- **Coverage below 80%:** Add tests to increase coverage

#### 2. Integration Tests Job

**What it does:**
- Spins up PostgreSQL service container
- Generates Prisma client
- Runs database migrations
- Executes integration tests with schema-per-run isolation

**Local equivalent:**
```bash
pnpm db:up                   # Start PostgreSQL
pnpm prisma:generate         # Generate Prisma client
pnpm prisma:migrate:deploy   # Run migrations
pnpm test:integration        # Run integration tests
```

**Common failures:**
- **Migration fails:** Check migration files in `apps/web/prisma/migrations/`
- **Connection errors:** Verify DATABASE_URL is set correctly
- **Schema conflicts:** Ensure schema-per-run creates unique schemas
- **Test failures:** Check test logs for specific failures

#### 3. E2E Tests Job

**What it does:**
- Installs Playwright browsers (Chromium)
- Runs E2E tests in CI mode (next build + next start)
- Uploads test reports and traces on failure

**Local equivalent:**
```bash
npx playwright install chromium  # Install browser (first time only)
pnpm test:e2e:ci                 # Run E2E tests in CI mode
```

**Common failures:**
- **Browser not found:** Playwright cache issue, will reinstall on retry
- **Server timeout:** Build step taking too long, check Next.js build
- **Test failures:** Check Playwright report artifact for screenshots/traces
- **Selector errors:** UI changed, update selectors in E2E tests

### Debugging CI Failures

**View detailed logs:**
1. Click on the failing job in GitHub Actions
2. Expand the failed step to see full output
3. Check uploaded artifacts for reports (coverage, Playwright)

**Reproduce locally:**
Run the exact commands from the failed job (see "Local equivalent" above).

**Playwright failures:**
1. Download the `playwright-report` artifact from the failed run
2. Extract and open `index.html` to see interactive report
3. View screenshots, traces, and video recordings of failures

**Integration test failures:**
1. Check if migrations are up to date: `pnpm prisma:migrate:deploy`
2. Verify PostgreSQL is running: `pnpm db:up`
3. Check DATABASE_URL matches expected format
4. Run tests locally with same DATABASE_URL as CI

### CI Status Checks

All three jobs must pass before a PR can be merged:
- ✅ Quality Gates
- ✅ Integration Tests
- ✅ E2E Tests

**Note:** The CI pipeline runs automatically on pull requests, but it only becomes a **merge gate** when branch protection is configured in GitHub (see Branch Protection Setup below).

## Branch Protection Setup (Phase 0.9.1)

**IMPORTANT:** The CI pipeline (Phase 0.8+) runs on all pull requests, but it does **NOT automatically block merging** unless branch protection rules are configured in GitHub.

### Why Branch Protection Matters

Without branch protection:
- ❌ PRs can be merged even if CI fails
- ❌ PRs can be merged without code review
- ❌ Direct commits to `main` are allowed
- ❌ Force pushes can overwrite history

With branch protection:
- ✅ CI must pass before merging
- ✅ Code review required
- ✅ Direct commits to `main` blocked
- ✅ Branch must be up-to-date with base
- ✅ Force pushes prevented

### Exact GitHub Configuration Steps

**Prerequisites:**
- Repository admin access
- CI pipeline already configured (Phase 0.8+)

**Steps:**

1. **Navigate to Branch Protection Settings**
   - Go to your repository on GitHub
   - Click **Settings** (top right)
   - Click **Branches** in the left sidebar
   - Under "Branch protection rules", click **Add rule**

2. **Configure Branch Name Pattern**
   - In "Branch name pattern", enter: `main`
   - This applies the rule to the main branch

3. **Enable Pull Request Requirements**
   - ✅ Check **Require a pull request before merging**
   - Under this, configure:
     - ✅ **Require approvals**: Set to `1` (minimum)
     - ✅ **Dismiss stale pull request approvals when new commits are pushed**
     - ⬜ **Require review from Code Owners** (optional, if CODEOWNERS file exists)
     - ⬜ **Restrict who can dismiss pull request reviews** (optional)

4. **Enable Status Check Requirements**
   - ✅ Check **Require status checks to pass before merging**
   - Under this, configure:
     - ✅ **Require branches to be up to date before merging** (recommended)
     - In the search box below "Status checks that are required", add:
       - `quality` (enter and select)
       - `integration` (enter and select)
       - `e2e` (enter and select)
   - **Note:** These status check names must match the job names in `.github/workflows/ci.yml`

5. **Additional Recommended Settings**
   - ✅ **Require conversation resolution before merging** (recommended)
   - ✅ **Require signed commits** (optional, for enhanced security)
   - ✅ **Require linear history** (optional, prevents merge commits)
   - ✅ **Do not allow bypassing the above settings** (prevents admin bypass)
   - ⬜ **Allow force pushes** (leave unchecked - prevents history rewriting)
   - ⬜ **Allow deletions** (leave unchecked - prevents branch deletion)

6. **Lock Down the Main Branch (Advanced)**
   - ✅ **Restrict who can push to matching branches** (optional)
     - Select specific users or teams allowed to push (usually none for `main`)
   - This ensures ALL changes go through pull requests

7. **Save Configuration**
   - Click **Create** (or **Save changes** if editing existing rule)
   - Branch protection is now active

### Verification Checklist

After configuring branch protection, verify it works:

1. **Test CI Enforcement:**
   ```bash
   # Create a test branch with intentional failure
   git checkout -b test/branch-protection

   # Make a change that breaks linting (e.g., add extra spaces)
   echo "const x  =  1" >> apps/web/src/test-file.ts

   git add .
   git commit -m "test: verify branch protection"
   git push -u origin test/branch-protection
   ```

   - Create a PR from this branch to `main`
   - Verify that GitHub shows **failing status checks**
   - Verify that the **"Merge pull request"** button is disabled or shows warning
   - Expected message: "Merging is blocked - Required status checks must pass"

2. **Test PR Approval Requirement:**
   - Create a PR with passing CI
   - Without approval, try to merge
   - Expected: "Merging is blocked - Requires 1 approving review"

3. **Test Direct Push Protection:**
   ```bash
   git checkout main
   git pull
   echo "test" >> README.md
   git commit -am "test: direct push"
   git push
   ```
   - Expected error: `refusing to allow a personal access token to push to a protected branch`
   - **Note:** This confirms direct pushes are blocked

4. **Clean Up Test Branch:**
   ```bash
   git checkout main
   git branch -D test/branch-protection
   git push origin --delete test/branch-protection
   ```

### Current Protection Status

**As of Phase 0.9.1:**
- ✅ CI pipeline configured (quality, integration, e2e jobs)
- ⏳ Branch protection rules (manual configuration required)

**To enable enforcement:**
Follow the exact steps above to configure branch protection in GitHub Settings.

### Troubleshooting

**Problem:** Status checks not appearing in the dropdown
- **Cause:** The CI workflow hasn't run yet on a PR
- **Solution:** Create a test PR first, wait for CI to run, then configure branch protection

**Problem:** "Merge" button still enabled despite failing CI
- **Cause:** Branch protection not configured or status check names don't match
- **Solution:**
  1. Verify rule is applied to `main` branch
  2. Verify status check names match exactly: `quality`, `integration`, `e2e`
  3. Check that "Require status checks to pass before merging" is checked

**Problem:** Can't merge even with passing CI
- **Cause:** Branch not up-to-date with base
- **Solution:** Click "Update branch" button in PR or run `git pull origin main && git push`

**Problem:** Admin can still bypass protections
- **Cause:** "Do not allow bypassing the above settings" is unchecked
- **Solution:** Enable this setting to enforce rules even for admins

## Security Settings (Phase 0.9.2)

**IMPORTANT:** Dependabot and security scanning features are configured in `.github/dependabot.yml`, but additional security features must be enabled manually in GitHub repository settings.

### Automated Dependency Updates (Dependabot)

**Already Configured (Phase 0.9.2):**
- ✅ `.github/dependabot.yml` exists and scans:
  - npm dependencies (pnpm workspace, weekly schedule)
  - GitHub Actions (weekly schedule)
- ✅ Updates grouped to reduce PR noise:
  - `dev-dependencies` group (tooling: eslint, prettier, vitest, playwright, etc.)
  - `runtime-dependencies` group (next, react, prisma)
- ✅ Maximum 5 open dependency PRs at a time
- ✅ Conventional commit format: `chore(deps):` or `chore(ci):`

**Manual Configuration Required (GitHub UI):**

Dependabot configuration file alone is not enough. Repository admins must enable Dependabot features in GitHub Settings:

1. **Enable Dependabot Alerts**
   - Go to **Settings → Code security and analysis**
   - Under "Dependabot alerts":
     - Click **Enable** (if not already enabled)
   - This provides vulnerability alerts for dependencies

2. **Enable Dependabot Security Updates**
   - In the same section, under "Dependabot security updates":
     - Click **Enable** (if not already enabled)
   - This automatically creates PRs for security vulnerabilities
   - **Note:** This is separate from version updates (configured in `dependabot.yml`)

3. **Enable Dependabot Version Updates**
   - Under "Dependabot version updates":
     - Should show **"Dependabot is active"** if `dependabot.yml` is valid
   - If not active, check the configuration file for syntax errors

### Secret Scanning and Push Protection

**Manual Configuration Required (GitHub UI):**

1. **Enable Secret Scanning**
   - Go to **Settings → Code security and analysis**
   - Under "Secret scanning":
     - Click **Enable** (if available - may require GitHub Advanced Security for private repos)
   - Scans repository for accidentally committed secrets (API keys, tokens, etc.)

2. **Enable Secret Scanning Push Protection** (Recommended)
   - Under "Secret scanning push protection":
     - Click **Enable** (if available)
   - **Prevents** pushes containing detected secrets
   - Developers will receive an error when attempting to push secrets
   - Provides option to bypass (with justification) if it's a false positive

### Security Settings Verification Checklist

After configuring settings, verify:

- [ ] **Dependabot alerts enabled** - Visit "Security" tab → "Dependabot alerts"
- [ ] **Dependabot security updates enabled** - Check for auto-generated security PRs
- [ ] **Dependabot version updates active** - Check for weekly update PRs (Mondays)
- [ ] **Secret scanning enabled** - Visit "Security" tab → "Secret scanning"
- [ ] **Push protection enabled** - Test by trying to commit a fake API key locally

### Current Security Status

**As of Phase 0.9.2:**
- ✅ Dependabot configuration file created
- ⏳ Dependabot alerts (manual GitHub UI configuration required)
- ⏳ Dependabot security updates (manual GitHub UI configuration required)
- ⏳ Secret scanning (manual GitHub UI configuration required)
- ⏳ Secret scanning push protection (manual GitHub UI configuration required)

**To enable full security scanning:**
Follow the exact steps above to configure security features in GitHub Settings.

### Dependency Update Review Policy

See [docs/POLICIES.md](POLICIES.md#dependency-management-phase-092) for:
- Dependency update review and merge timelines
- Emergency security patch workflow
- Breaking change handling

## Security Scanning (Phase 0.9.3)

ZollPilot uses multiple layers of automated security scanning to detect vulnerabilities, security issues, and dependency risks. Understanding what each scanner does and where to view results is essential for maintaining security posture.

### Security Scanning Layers

We use three complementary scanning approaches:

#### 1. CI Quality Gates (Phase 0.8+)
**What:** Linting, type checking, and unit/integration/E2E tests
**When:** Every pull request and push
**Catches:**
- Code quality issues
- Type errors
- Broken functionality
- Test failures

**View Results:** GitHub Actions → CI workflow run

#### 2. CodeQL Security Analysis (Phase 0.9.3)
**What:** Static Application Security Testing (SAST) for JavaScript/TypeScript
**When:**
- Every pull request to `main`
- Every push to `main`
- Weekly schedule (Mondays, 06:00 UTC)

**Catches:**
- SQL injection vulnerabilities
- Cross-site scripting (XSS)
- Path traversal issues
- Command injection
- Insecure randomness
- Hardcoded credentials
- And 100+ other security patterns

**View Results:**
1. Go to repository **Security** tab
2. Click **Code scanning** in left sidebar
3. View alerts filtered by:
   - Branch
   - Severity (Critical, High, Medium, Low)
   - Status (Open, Dismissed, Fixed)
4. Click individual alert for:
   - Full description and remediation
   - Code location and data flow
   - CWE classification

**Result Integration:**
- CodeQL findings appear as checks on pull requests
- High/Critical findings should block merging (configure in branch protection)
- Results uploaded to GitHub Security dashboard automatically

#### 3. Dependabot Security Alerts (Phase 0.9.2)
**What:** Dependency vulnerability scanning (Software Composition Analysis)
**When:** Continuous monitoring, PRs created weekly
**Catches:**
- Known CVEs in npm packages
- Outdated dependencies with security fixes
- Transitive dependency vulnerabilities

**View Results:**
1. Go to repository **Security** tab
2. Click **Dependabot alerts** in left sidebar
3. Or view auto-generated Dependabot PRs in **Pull requests** tab

### How to Handle Security Findings

**CodeQL Alerts:**
See [docs/POLICIES.md](POLICIES.md#codeql-findings-phase-093) for severity handling and remediation workflow.

**Dependabot Alerts:**
See [docs/POLICIES.md](POLICIES.md#dependency-management-phase-092) for review SLAs and emergency patch process.

### Local Security Scanning

**Recommended Pre-Commit Checks:**
```bash
# Run all quality gates (includes basic security checks)
pnpm lint        # ESLint catches some security anti-patterns
pnpm typecheck   # Type safety prevents many runtime errors
pnpm test        # Tests catch regressions and bugs

# Audit dependencies for high/critical vulnerabilities (Phase 0.11)
pnpm security:audit  # Check for high/critical CVEs (same as CI)

# Full audit (all severities, more verbose)
pnpm audit           # Check all CVE severities
pnpm audit --fix     # Automatically fix vulnerabilities when possible
```

**Note:** CodeQL requires GitHub infrastructure and cannot run fully locally, but you can use ESLint security plugins for similar local checks (future enhancement).

### Security Scanning Status

**As of Phase 0.11:**
- ✅ CI quality gates enforced (Phase 0.8+)
- ✅ CodeQL analysis configured (Phase 0.9.3)
- ✅ Dependabot alerts enabled (Phase 0.9.2, requires GitHub UI config)
- ✅ Dependency security audit (Phase 0.11) - high/critical vulnerabilities block CI
- ✅ HTTP security headers enforced (Phase 0.11) - runtime E2E tested
- ✅ Environment validation (Phase 0.11) - fail-fast on misconfiguration
- ⏳ CodeQL results as required status check (configure in branch protection)
- ⏳ ESLint security plugin (Phase 1.x)

## Documentation Drift Gate (Phase 0.10)

**Documentation drift** occurs when documentation becomes outdated and no longer matches the code. This is prevented through automated checks that validate documentation stays in sync with implementation.

### What is Checked

The `docs:check` command validates:

1. **Internal Markdown Links**
   - Relative links (e.g., `[Setup](./SETUP.md)`, `[../README.md](../README.md)`)
   - File existence validation
   - Anchor validation (e.g., `[Branch Protection](./CONTRIBUTING.md#branch-protection-setup-phase-091)`)
   - Detects broken links before they reach users

2. **Documented Routes/Endpoints**
   - Extracts routes mentioned in documentation (e.g., `/admin`, `/api/health`, `/verfahren/[slug]`)
   - Verifies routes exist in Next.js app structure:
     - Pages: `apps/web/src/app/**/page.tsx`
     - API routes: `apps/web/src/app/api/**/route.ts`
   - Prevents documentation from describing non-existent features
   - Ignores routes in code blocks (fenced with ` ``` `)

3. **Route Mapping Examples**
   - `/admin` → `apps/web/src/app/admin/page.tsx`
   - `/api/health` → `apps/web/src/app/api/health/route.ts`
   - `/verfahren/[slug]` → `apps/web/src/app/verfahren/[slug]/page.tsx`

### How to Run Locally

**Before committing documentation changes:**

```bash
# Run documentation drift check
pnpm docs:check
```

**Expected output (success):**

```
🔍 Documentation Drift Check

📂 Docs directory: docs
📂 Route base: apps/web/src/app

📄 Found 7 markdown files

📝 Validating internal markdown links...
🛣️  Validating documented routes...
   Found 2 documented routes

📊 Results

✅ No documentation drift detected
   7 files checked
   0 warnings (non-blocking)
```

**Expected output (failure):**

```
❌ Errors:
   docs/SETUP.md:42 - Broken link: "./MISSING.md" (target not found: docs/MISSING.md)
   docs/CONTRIBUTING.md - Documented route "/api/fake" not found in code (expected: apps/web/src/app/api/fake/route.ts)

❌ Documentation drift detected: 2 error(s)

💡 To fix:
   1. Update documentation to match code
   2. Add missing routes/pages to code
   3. Add to ignoredRoutes in scripts/docs-check.config.json (with justification)
```

### CI Enforcement

Documentation drift check runs as a **required CI job** on all pull requests:
- Job name: "Documentation Drift Check"
- Runs in parallel with other quality gates
- Must pass before merging (when branch protection configured)
- Typical runtime: <5 seconds

### Allowlist for Planned Features

Sometimes you need to document a route that doesn't exist yet (planned feature). Use the allowlist sparingly:

**Configuration file:** `scripts/docs-check.config.json`

```json
{
  "routeBaseDir": "apps/web/src/app",
  "ignoredRoutes": [
    "/verfahren/[slug]"  // Planned for Phase 1.2
  ],
  "ignoredFiles": []
}
```

**Rules for using allowlist:**
1. **Always add a comment** explaining why the route is allowlisted
2. **Include a phase/sprint reference** for when it will be implemented
3. **Remove from allowlist** when the route is implemented
4. **Review allowlist quarterly** to remove obsolete entries
5. **Prefer implementing the route** over adding to allowlist

**Anti-patterns (DO NOT DO):**
- Adding all planned routes to allowlist upfront
- Using allowlist to avoid fixing broken links
- Leaving items in allowlist indefinitely
- Allowlisting without documentation of reason

### Common Scenarios

**Scenario 1: Broken Link After File Rename**

```bash
# Error: docs/SETUP.md:15 - Broken link: "./OLD_NAME.md"

# Fix: Update the link to the new filename
sed -i 's/OLD_NAME.md/NEW_NAME.md/g' docs/SETUP.md
```

**Scenario 2: Documented Route Not Yet Implemented**

```bash
# Error: Documented route "/dashboard" not found

# Option A (preferred): Implement the route
mkdir -p apps/web/src/app/dashboard
touch apps/web/src/app/dashboard/page.tsx

# Option B (temporary): Add to allowlist with justification
# Edit scripts/docs-check.config.json:
{
  "ignoredRoutes": ["/dashboard"]  // Phase 1.3 - Dashboard implementation
}
```

**Scenario 3: Anchor Not Found**

```bash
# Warning (non-blocking): Anchor not found: "security-settings" in docs/CONTRIBUTING.md

# Fix: Check heading spelling/capitalization
# Anchors are case-sensitive and auto-generated from headings:
# "Security Settings" → "security-settings"
# "API Documentation" → "api-documentation"
```

### Best Practices

1. **Run `pnpm docs:check` before every documentation commit**
2. **Update docs when adding/removing routes**
3. **Use relative links** for internal documentation (e.g., `./SETUP.md`, not absolute paths)
4. **Test anchor links** - anchors are generated from headings, ensure they match
5. **Keep allowlist minimal** - prefer fixing issues over ignoring them

### Integration with Other Gates

Documentation drift check complements other quality gates:

| Gate | What It Checks | When |
|------|----------------|------|
| **docs:check** | Docs ↔ Code sync | Every PR (fast, <5s) |
| **typecheck** | Type correctness | Every PR |
| **test:unit** | Code functionality | Every PR |
| **test:integration** | Database + API | Every PR |
| **test:e2e** | User flows | Every PR |
| **CodeQL** | Security issues | PR + weekly |

### Quality Gates (Phase 0.4+)

**ENFORCED:** These checks must pass before merging. Run them locally before creating a PR.

#### Run All Quality Gates

```bash
# Check all gates at once
pnpm lint && pnpm typecheck && pnpm test:coverage && pnpm format
```

#### Individual Quality Gates

**1. Linting (ESLint)**

Checks code for style issues and potential bugs.

```bash
# Check for linting errors
pnpm lint

# Auto-fix linting errors (when possible)
pnpm --filter @zollpilot/web lint --fix
```

**2. Type Checking (TypeScript)**

Validates TypeScript types in strict mode.

```bash
# Run type checking
pnpm typecheck
```

**3. Testing with Coverage**

Runs all tests and enforces ≥80% coverage on lines, functions, branches, and statements.

```bash
# Run tests without coverage (fast)
pnpm test

# Run tests with coverage (enforces thresholds)
pnpm test:coverage

# Watch mode for development
pnpm --filter @zollpilot/web test:watch
```

**Coverage Thresholds (ENFORCED):**
- Lines: ≥80%
- Functions: ≥80%
- Branches: ≥80%
- Statements: ≥80%

**Note:** `test:coverage` will FAIL if any threshold is not met. This is intentional.

**4. Code Formatting (Prettier)**

Ensures consistent code formatting across the codebase.

```bash
# Check formatting (CI-safe)
pnpm format

# Apply formatting (fix)
pnpm format:write
```

#### Pre-Commit Checklist

Before committing, ensure:
1. ✅ `pnpm lint` passes
2. ✅ `pnpm typecheck` passes
3. ✅ `pnpm test:coverage` passes (all tests + coverage ≥80%)
4. ✅ `pnpm format` passes

#### TDD Reminder

**MANDATORY:** Write tests BEFORE implementation.

1. Write failing test
2. Run `pnpm test:watch` (watch mode)
3. Implement minimal code to pass
4. Verify coverage with `pnpm test:coverage`
5. Refactor if needed
6. Commit

#### Nothing Undocumented Reminder

Every feature must be documented:
- Public features → `docs/USER_MANUAL.md`
- Admin features → `docs/ADMIN_MANUAL.md`
- Technical changes → `docs/SETUP.md` or `docs/ARCHITECTURE.md`
- Breaking changes → Update `CONTRIBUTING.md`

## Code Standards

### TypeScript

- Use strict mode
- Prefer interfaces over types for public APIs
- Use type inference where possible
- Document complex types

### File Organization

```typescript
// 1. Imports (external, then internal)
import { useState } from 'react'
import { Button } from '@/components'

// 2. Types and interfaces
interface Props { ... }

// 3. Constants
const MAX_RETRIES = 3

// 4. Implementation
export function Component() { ... }
```

### Naming Conventions

- **Files:** kebab-case (`user-service.ts`)
- **Components:** PascalCase (`UserProfile.tsx`)
- **Functions:** camelCase (`getUserData()`)
- **Constants:** UPPER_SNAKE_CASE (`MAX_RETRY_COUNT`)
- **Types/Interfaces:** PascalCase (`UserData`)

## Testing Standards

### Test Layers (Phase 0.5+)

ZollPilot has **three distinct test layers**:

#### 1. Unit Tests

**Purpose:** Fast, isolated tests for individual components and functions

**Characteristics:**
- File naming: `*.test.{ts,tsx}` (NOT `*.int.test.{ts,tsx}`)
- Environment: jsdom (browser-like for React components)
- No database required
- No external dependencies
- Mocked where necessary

**Example:**
```typescript
// src/app/page.test.tsx
import { render, screen } from '@testing-library/react'
import Page from './page'

describe('Home Page', () => {
  it('should render welcome message', () => {
    render(<Page />)
    expect(screen.getByText(/welcome/i)).toBeInTheDocument()
  })
})
```

**Run unit tests:**
```bash
pnpm test:unit
```

#### 2. Integration Tests

**Purpose:** Tests that verify database interactions and multi-module integration

**Characteristics:**
- File naming: `*.int.test.{ts,tsx}` (MUST include `.int.`)
- Environment: node
- Requires PostgreSQL database
- Uses real Prisma client
- Schema-per-run isolation (each test run uses unique schema)

**Example:**
```typescript
// src/server/db.int.test.ts
import { describe, it, expect, afterEach } from 'vitest'
import { prisma } from '@/server/db'
import { truncateAll } from '../../test/db-utils'
import { createTenant, createUser } from '../../test/factories'

describe('Database Integration', () => {
  afterEach(async () => {
    await truncateAll(prisma)
  })

  it('should create and query tenant', async () => {
    const tenant = await createTenant(prisma, {
      name: 'Test Tenant'
    })

    const found = await prisma.tenant.findUnique({
      where: { id: tenant.id }
    })

    expect(found).toEqual(tenant)
  })
})
```

**Prerequisites:**
```bash
# Start database
pnpm db:up

# Run integration tests
pnpm test:integration
```

**Schema-Per-Run Isolation:**
- Each test run creates a unique schema (e.g., `test_1234567890_abc12`)
- Tests never touch development data
- Global setup creates schema and runs migrations
- Global teardown drops schema
- Use `truncateAll()` in `afterEach` to clean between tests

**Test Utilities:**

```typescript
// Database cleanup
import { truncateAll } from '../../test/db-utils'
await truncateAll(prisma) // Clears all tables in test schema

// Data factories (auto-create dependencies)
import { createTenant, createUser, createAuditEvent } from '../../test/factories'

const tenant = await createTenant(prisma)
const admin = await createUser(prisma, {
  tenantId: tenant.id,
  email: 'admin@test.local',
  role: 'ADMIN'
})
```

**Run integration tests:**
```bash
pnpm test:integration
```

#### 3. E2E Tests (Phase 0.6+)

**Purpose:** End-to-end user flows tested in real browser with Playwright

**Characteristics:**
- File naming: `*.e2e.spec.{ts,tsx}` (MUST include `.e2e.`)
- Environment: Chromium browser (real browser automation)
- No database required in Phase 0
- Located in `apps/web/e2e/` directory
- Tests full user workflows and UI interactions

**Example:**
```typescript
// e2e/home.e2e.spec.ts
import { test, expect } from '@playwright/test'

test.describe('Home Page', () => {
  test('should navigate to admin', async ({ page }) => {
    await page.goto('/')

    // Use role-based selectors for resilience
    const adminLink = page.getByRole('link', { name: /admin/i })
    await adminLink.click()

    await expect(page).toHaveURL('/admin')
    await expect(page.getByRole('heading', { name: /admin/i })).toBeVisible()
  })
})
```

**Run E2E tests:**
```bash
# Local dev mode (fast)
pnpm test:e2e

# CI mode (build + start, stable)
pnpm test:e2e:ci

# Interactive UI mode
pnpm test:e2e:ui
```

**Prerequisites:**
```bash
# First-time setup: install browsers
npx playwright install chromium
```

### Test Structure

```typescript
describe('Feature', () => {
  describe('Scenario', () => {
    it('should do something specific', () => {
      // Arrange
      const input = ...

      // Act
      const result = ...

      // Assert
      expect(result).toBe(...)
    })
  })
})
```

### Choosing the Right Test Layer

**Use Unit Tests for:**
- React component rendering and props
- Pure functions and utilities
- Business logic without database
- Anything that can be tested in isolation

**Use Integration Tests for:**
- Database queries and mutations
- Prisma model interactions
- Multi-tenancy isolation
- Audit trail generation
- API routes that use database

**Use E2E Tests for:**
- Full user workflows (navigation, forms, multi-step processes)
- Browser-specific behavior (rendering, responsive design)
- Authentication flows (login, logout, session management)
- Cross-page interactions and navigation
- Critical user journeys (smoke tests)
- UI interactions that can't be tested with unit/integration tests

### Coverage Requirements

- **Minimum:** 80% overall coverage (unit tests)
- **Critical paths:** 100% coverage
- **Public APIs:** 100% coverage
- **Integration tests:** Must cover all database models and interactions

## Documentation Standards

### Code Comments

- Explain **why**, not **what**
- Document assumptions and edge cases
- Use JSDoc for public APIs

### Architecture Decision Records (ADR)

Significant technical decisions must be documented in `docs/adr/`.

Format:
```markdown
# ADR-001: Decision Title

## Status
Accepted / Rejected / Superseded

## Context
Background and problem

## Decision
What we decided

## Consequences
Impact and tradeoffs
```

## Audit & Logging Policy

**CRITICAL:** Every admin action must generate an audit event.

Requirements:
- Immutable audit logs
- Include: timestamp, user, action, resource, old/new values
- No PII in logs without encryption
- Retention policy: TBD

## Security Guidelines

- Never commit secrets or credentials
- Use environment variables for configuration
- Validate all user input
- Sanitize all output
- Follow OWASP guidelines
- Security review required for auth/authz changes

## Getting Help

- Review existing documentation
- Check GitHub issues
- Ask in team chat
- Create issue for bugs or feature requests

## License

All contributions must comply with the project license (UNLICENSED).
